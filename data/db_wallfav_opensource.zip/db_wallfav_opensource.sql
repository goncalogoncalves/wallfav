-- --------------------------------------------------------
-- Anfitrião:                    127.0.0.1
-- Versão do servidor:           5.7.11 - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Versão:              9.5.0.5253
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping structure for table wallfav_opensource.categorias
CREATE TABLE IF NOT EXISTS `categorias` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `NOME` varchar(255) NOT NULL DEFAULT '0',
  `USER_ID` int(10) NOT NULL DEFAULT '0',
  `COR_BACKGROUND` varchar(255) NOT NULL DEFAULT '0',
  `COR_TEXTO` varchar(255) NOT NULL DEFAULT '0',
  `DATA` datetime NOT NULL,
  `ORDEM` int(10) NOT NULL DEFAULT '100',
  PRIMARY KEY (`ID`),
  KEY `USER_ID` (`USER_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Dumping data for table wallfav_opensource.categorias: ~0 rows (approximately)
/*!40000 ALTER TABLE `categorias` DISABLE KEYS */;
INSERT INTO `categorias` (`ID`, `NOME`, `USER_ID`, `COR_BACKGROUND`, `COR_TEXTO`, `DATA`, `ORDEM`) VALUES
	(1, 'Teste', 1, '1384ad', '555', '2018-02-21 14:46:21', 100);
/*!40000 ALTER TABLE `categorias` ENABLE KEYS */;

-- Dumping structure for table wallfav_opensource.configs
CREATE TABLE IF NOT EXISTS `configs` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `WEBSITE_TITULO` varchar(500) DEFAULT NULL,
  `WEBSITE_DESCRICAO` varchar(1000) DEFAULT NULL,
  `WEBSITE_KEYWORDS` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='configurações do website';

-- Dumping data for table wallfav_opensource.configs: ~0 rows (approximately)
/*!40000 ALTER TABLE `configs` DISABLE KEYS */;
INSERT INTO `configs` (`ID`, `WEBSITE_TITULO`, `WEBSITE_DESCRICAO`, `WEBSITE_KEYWORDS`) VALUES
	(1, 'wallfav', 'put your favourite websites on a wall!', 'wallfav, wall, fav, favourite,favourites, websites, bookmarks, manager, free, organizer, favorites, discover, list, export, marcadores, organizar');
/*!40000 ALTER TABLE `configs` ENABLE KEYS */;

-- Dumping structure for table wallfav_opensource.feedback
CREATE TABLE IF NOT EXISTS `feedback` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(10) NOT NULL DEFAULT '0',
  `TEXTO` varchar(1000) NOT NULL DEFAULT '0',
  `DATA` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`ID`),
  KEY `USER_ID` (`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table wallfav_opensource.feedback: ~0 rows (approximately)
/*!40000 ALTER TABLE `feedback` DISABLE KEYS */;
/*!40000 ALTER TABLE `feedback` ENABLE KEYS */;

-- Dumping structure for table wallfav_opensource.routes
CREATE TABLE IF NOT EXISTS `routes` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `VALOR` varchar(255) DEFAULT NULL,
  `LIGACAO` varchar(1000) DEFAULT NULL,
  `VISIVEL` tinyint(4) DEFAULT '1',
  `VALIDA` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8 COMMENT='config das rotas';

-- Dumping data for table wallfav_opensource.routes: ~45 rows (approximately)
/*!40000 ALTER TABLE `routes` DISABLE KEYS */;
INSERT INTO `routes` (`ID`, `VALOR`, `LIGACAO`, `VISIVEL`, `VALIDA`) VALUES
	(1, '/', 'Home:index', 1, 1),
	(2, '/error', 'Home:error', 1, 1),
	(3, '/not_found', 'Home:notFound', 1, 1),
	(4, '/without_permission', 'Home:withoutPermission', 1, 1),
	(10, '/login', 'Login:index', 1, 1),
	(11, '/login/', 'Login:index', 1, 1),
	(12, '/login/login', 'Login:login', 1, 1),
	(13, '/login/logout', 'Login:logout', 1, 1),
	(14, '/login/register', 'Login:register', 1, 1),
	(15, '/login/registerUser', 'Login:registerUser', 1, 1),
	(16, '/login/addCaptcha', 'Login:addCaptcha', 1, 1),
	(17, '/login/validateCaptcha', 'Login:validateCaptcha', 1, 1),
	(19, '/login/verify', 'Login:verify', 1, 1),
	(20, '/login/loginWithFacebook', 'Login:loginWithFacebook', 1, 1),
	(21, '/dashboard', 'Dashboard:index', 1, 1),
	(22, '/dashboard/sendFeedback', 'Dashboard:sendFeedback', 1, 1),
	(23, '/dashboard/addCategory', 'Dashboard:addCategory', 1, 1),
	(24, '/dashboard/addWebsite', 'Dashboard:addWebsite', 1, 1),
	(25, '/coffee', 'Home:coffee', 1, 1),
	(26, '/dashboard/loadWebsitesDesorganizados', 'Dashboard:loadWebsitesDesorganizados', 1, 1),
	(27, '/dashboard/deleteWebsite', 'Dashboard:deleteWebsite', 1, 1),
	(28, '/dashboard/loadCategorias', 'Dashboard:loadCategorias', 1, 1),
	(29, '/dashboard/saveLayout', 'Dashboard:saveLayout', 1, 1),
	(30, '/dashboard/saveWebsitePosition', 'Dashboard:saveWebsitePosition', 1, 1),
	(31, '/dashboard/loadCategoryContent', 'Dashboard:loadCategoryContent', 1, 1),
	(32, '/dashboard/loadInfoCategory', 'Dashboard:loadInfoCategory', 1, 1),
	(33, '/dashboard/saveInfoCategory', 'Dashboard:saveInfoCategory', 1, 1),
	(34, '/dashboard/loadDestaques', 'Dashboard:loadDestaques', 1, 1),
	(35, '/dashboard/deleteCategory', 'Dashboard:deleteCategory', 1, 1),
	(36, '/terms-and-conditions', 'Home:terms', 1, 1),
	(37, '/contacts', 'Home:contacts', 1, 1),
	(38, '/privacy', 'Home:privacy', 1, 1),
	(39, '/send-feedback', 'Home:sendFeedback', 1, 1),
	(40, '/settings', 'Dashboard:settings', 1, 1),
	(41, '/register', 'Login:register', 1, 1),
	(42, '/delete-account', 'Home:deleteAccount', 1, 1),
	(43, '/deleteAccountNow', 'Home:deleteAccountNow', 1, 1),
	(44, '/change-password', 'Dashboard:changePassword', 1, 1),
	(45, '/export-info', 'Dashboard:exportInfo', 1, 1),
	(46, '/verify', 'Login:verify', 1, 1),
	(47, '/login/accountActivated', 'Login:accountActivated', 1, 1),
	(48, '/login/accountNotActivated', 'Login:accountNotActivated', 1, 1),
	(49, '/login/sendVerificationEmail', 'Login:sendVerificationEmail', 1, 1),
	(50, '/login/requestPasswordReset', 'Login:requestPasswordReset', 1, 1),
	(51, '/login/passwordReset', 'Login:passwordReset', 1, 1);
/*!40000 ALTER TABLE `routes` ENABLE KEYS */;

-- Dumping structure for table wallfav_opensource.users
CREATE TABLE IF NOT EXISTS `users` (
  `USER_ID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'auto incrementing user_id of each user, unique index',
  `USER_NAME` varchar(64) COLLATE utf8_unicode_ci NOT NULL COMMENT 'user''s name, unique',
  `USER_PASSWORD_HASH` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'user''s password in salted and hashed format',
  `USER_EMAIL` varchar(64) COLLATE utf8_unicode_ci NOT NULL COMMENT 'user''s email, unique',
  `USER_ACTIVE` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'user''s activation status',
  `USER_ACCOUNT_TYPE` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'user''s account type (basic, premium, etc)',
  `DATA_CRIACAO` varchar(50) COLLATE utf8_unicode_ci DEFAULT '0',
  `USER_PROVIDER_TYPE` text COLLATE utf8_unicode_ci,
  `IP` varchar(255) COLLATE utf8_unicode_ci DEFAULT '0',
  `USER_COUNTRY` varchar(255) COLLATE utf8_unicode_ci DEFAULT '0',
  `USER_CITY` varchar(255) COLLATE utf8_unicode_ci DEFAULT '0',
  `USER_FAILED_LOGINS` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'user''s failed login attempts',
  `HTTP_USER_AGENT` varchar(255) COLLATE utf8_unicode_ci DEFAULT '0',
  `HTTP_REFERER` varchar(255) COLLATE utf8_unicode_ci DEFAULT '0',
  `USER_HOSTNAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT '0',
  `USER_REGION` varchar(255) COLLATE utf8_unicode_ci DEFAULT '0',
  `USER_LOC` varchar(255) COLLATE utf8_unicode_ci DEFAULT '0',
  `USER_ORG` varchar(255) COLLATE utf8_unicode_ci DEFAULT '0',
  `USER_FACEBOOK_UID` bigint(20) unsigned DEFAULT NULL COMMENT 'optional - facebook UID',
  `USER_FACEBOOK_EMAIL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_FACEBOOK_NAME` varchar(500) CHARACTER SET utf8 DEFAULT NULL,
  `USER_FACEBOOK_FIRST_NAME` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `USER_FACEBOOK_LAST_NAME` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `USER_FACEBOOK_GENDER` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `USER_FACEBOOK_LINK` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_FACEBOOK_LOCALE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_FACEBOOK_TIMEZONE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_FACEBOOK_UPDATED_TIME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_FACEBOOK_VERIFIED` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_REMEMBERME_TOKEN` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'user''s remember-me cookie token',
  `USER_HAS_AVATAR` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1 if user has a local avatar, 0 if not',
  `USER_LAST_LOGIN_TIMESTAMP` bigint(20) DEFAULT NULL COMMENT 'timestamp of user''s last login',
  `USER_CREATION_TIMESTAMP` bigint(20) DEFAULT NULL COMMENT 'timestamp of the creation of user''s account',
  `USER_LAST_FAILED_LOGIN` int(10) DEFAULT NULL COMMENT 'unix timestamp of last failed login attempt',
  `USER_PASSWORD_RESET_TIMESTAMP` bigint(20) DEFAULT NULL COMMENT 'timestamp of the password reset request',
  `USER_PASSWORD_RESET_HASH` char(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'user''s password reset code',
  `USER_ACTIVATION_HASH` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'user''s email verification hash string',
  PRIMARY KEY (`USER_ID`),
  UNIQUE KEY `user_email` (`USER_EMAIL`),
  KEY `user_facebook_uid` (`USER_FACEBOOK_UID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='user data';

-- Dumping data for table wallfav_opensource.users: ~1 rows (approximately)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`USER_ID`, `USER_NAME`, `USER_PASSWORD_HASH`, `USER_EMAIL`, `USER_ACTIVE`, `USER_ACCOUNT_TYPE`, `DATA_CRIACAO`, `USER_PROVIDER_TYPE`, `IP`, `USER_COUNTRY`, `USER_CITY`, `USER_FAILED_LOGINS`, `HTTP_USER_AGENT`, `HTTP_REFERER`, `USER_HOSTNAME`, `USER_REGION`, `USER_LOC`, `USER_ORG`, `USER_FACEBOOK_UID`, `USER_FACEBOOK_EMAIL`, `USER_FACEBOOK_NAME`, `USER_FACEBOOK_FIRST_NAME`, `USER_FACEBOOK_LAST_NAME`, `USER_FACEBOOK_GENDER`, `USER_FACEBOOK_LINK`, `USER_FACEBOOK_LOCALE`, `USER_FACEBOOK_TIMEZONE`, `USER_FACEBOOK_UPDATED_TIME`, `USER_FACEBOOK_VERIFIED`, `USER_REMEMBERME_TOKEN`, `USER_HAS_AVATAR`, `USER_LAST_LOGIN_TIMESTAMP`, `USER_CREATION_TIMESTAMP`, `USER_LAST_FAILED_LOGIN`, `USER_PASSWORD_RESET_TIMESTAMP`, `USER_PASSWORD_RESET_HASH`, `USER_ACTIVATION_HASH`) VALUES
	(1, '', '', 'user@domain.dev', 1, 1, '', 'DEFAULT', '', '', '', 0, '', 'http://wallfav.com/register', '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1519225058, 0, NULL, 0, '', NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

-- Dumping structure for table wallfav_opensource.websites
CREATE TABLE IF NOT EXISTS `websites` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `USER_ID` int(10) NOT NULL DEFAULT '0',
  `TITULO` varchar(255) NOT NULL DEFAULT '0',
  `LINK` varchar(1000) NOT NULL DEFAULT '0',
  `EM_DESTAQUE` tinyint(4) NOT NULL DEFAULT '0',
  `CATEGORIA` int(10) NOT NULL DEFAULT '0',
  `LINK_RAIZ` varchar(1000) NOT NULL DEFAULT '0',
  `ORDEM` int(10) NOT NULL DEFAULT '1',
  `DESCRICAO` varchar(1000) DEFAULT NULL,
  `KEYWORDS` varchar(1000) NOT NULL DEFAULT '0',
  `IMAGEM` varchar(1000) DEFAULT '0',
  `IMAGEM_2` varchar(1000) DEFAULT '0',
  `ICONE` varchar(1000) DEFAULT '0',
  `DATA` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`ID`),
  KEY `USER_ID` (`USER_ID`),
  KEY `CATEGORIA` (`CATEGORIA`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Dumping data for table wallfav_opensource.websites: ~0 rows (approximately)
/*!40000 ALTER TABLE `websites` DISABLE KEYS */;
INSERT INTO `websites` (`ID`, `USER_ID`, `TITULO`, `LINK`, `EM_DESTAQUE`, `CATEGORIA`, `LINK_RAIZ`, `ORDEM`, `DESCRICAO`, `KEYWORDS`, `IMAGEM`, `IMAGEM_2`, `ICONE`, `DATA`) VALUES
	(1, 1, 'YouTube', 'https://www.youtube.com', 0, 1, 'https://www.youtube.com', 1, 'Enjoy the videos and music you love, upload original content, and share it all with friends, family, and the world on YouTube.', 'video, sharing, camera phone, video phone, free, upload', 'http://www.google.com/s2/favicons?domain=www.youtube.com', '/yts/img/yt_1200-vfl4C3T0K.png', 'https://s.ytimg.com/yts/img/favicon-vfl8qSV2F.ico', '2018-02-21 14:46:33'),
	(2, 1, 'reddit: the front page of the internet', 'https://www.reddit.com/', 0, 0, 'https://www.reddit.com', 1, 'reddit: the front page of the internet', ' reddit, reddit.com, vote, comment, submit ', 'http://www.google.com/s2/favicons?domain=www.reddit.com', '', '', '2018-02-21 14:46:58');
/*!40000 ALTER TABLE `websites` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
